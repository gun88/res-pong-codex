(function($){
    /* IMPORTANT WARNING!
     *
     * In case of REST call with query parameters, remember to generate the final URL through the restUrl
     * function, providing the path and the parameters. This function creates the correct URL with query parameters
     * checking the permalink configuration of the site. If permalink mode is not enabled, query parameters must be
     * added joined by '&', otherwise, as usual, joined by '?'.
     */
    function renderCheckbox(data){
        return '<input type="checkbox" class="rp-select" value="' + data.id + '">';
    }
    function renderBool(val, id){
        return parseInt(val) === 1
            ? '<span class="dashicons dashicons-yes rp-icon-yes rp-toggle" data-id="' + id + '"></span>'
            : '<span class="dashicons dashicons-no-alt rp-icon-no rp-toggle" data-id="' + id + '"></span>';
    }
    function showOverlay(indeterminate){
        var overlay = $('#rp-progress-overlay');
        var bar = overlay.find('progress');
        var text = $('#rp-progress-text');
        if(indeterminate){
            bar.removeAttr('max').removeAttr('value');
            text.hide();
        }else{
            bar.attr({max:100, value:0});
            text.show().text('0%');
        }
        overlay.show();
        return {bar: bar, text: text};
    }
    function hideOverlay(){
        $('#rp-progress-overlay').hide();
    }
    function clearNotice(){
        $('.wrap').first().find('.notice').remove();
    }
    function showNotice(type, text){
        var wrap = $('.wrap').first();
        clearNotice();
        var notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + text + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
        notice.prependTo(wrap);
    }
    $(document).on('click', '.notice-dismiss', function(){
        $(this).closest('.notice').remove();
    });
    function showButtonMessage(btn, type, text){
        btn.siblings('.notice').remove();
        var notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + text + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
        btn.after(notice);
    }
    function rpConfirm(message){
        if(typeof window.jQuery === 'undefined'){
            return Promise.resolve(window.confirm(message));
        }
        return new Promise(function(resolve){
            var overlay = $('<div class="rp-confirm-overlay"></div>').appendTo('body');
            var dialog = $('<div class="rp-confirm-dialog"><p></p><div class="rp-confirm-buttons"><button class="button button-primary rp-confirm-yes">Si</button><button class="button rp-confirm-no">No</button></div></div>').appendTo(overlay);
            dialog.find('p').text(message);
            overlay.on('click', '.rp-confirm-yes', function(){
                overlay.remove();
                resolve(true);
            });
            overlay.on('click', '.rp-confirm-no', function(){
                overlay.remove();
                resolve(false);
            });
        });
    }
    function restUrl(path, params){
        var url = rp_admin.rest_url + path;
        if(params){
            url += (url.indexOf('?') === -1 ? '?' : '&') + params;
        }
        return url;
    }
    function actionButtons(entity, data){
        var edit = '<button class="button rp-edit rp-action-btn" data-id="' + data.id + '" title="Modifica"><span class="dashicons dashicons-edit"></span></button>';
        var del = '<button class="button rp-delete rp-button-danger rp-action-btn" data-id="' + data.id + '" title="Elimina"><span class="dashicons dashicons-trash"></span></button>';
        var buttons = edit + del;
        if(entity === 'users'){
            buttons += '<button class="button rp-impersonate rp-action-btn" data-id="' + data.id + '" title="Impersona"><span class="dashicons dashicons-admin-users"></span></button>';
            if(!data.password){
                buttons += '<button class="button rp-invite rp-action-btn" data-id="' + data.id + '" title="Invita"><span class="dashicons dashicons-email"></span></button>';
            }
        }else if(entity === 'events'){
            buttons += '<button class="button rp-contact rp-action-btn" data-id="' + data.id + '" title="Contatta"><span class="dashicons dashicons-email"></span></button>';
        }
        return '<div class="rp-action-group">' + buttons + '</div>';
    }
    var columns = {
        users: [
            { data: null, title: '', orderable: false, render: renderCheckbox },
            { data: 'name', title: 'Nome', render: function(d, type, row){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-user-detail&id=' + row.id + '">' + d + '</a>'; } },
            { data: 'id', title: 'Tessera', render: function(d){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-user-detail&id=' + d + '">' + d + '</a>'; } },
            { data: 'email', title: 'Email' },
            { data: 'username', title: 'Nome utente' },
            { data: 'category', title: 'Categoria' },
            { data: 'enabled', title: 'Abilitato', className: 'rp-icon-col', render: function(d, type, row){ return type === 'display' ? renderBool(d, row.id) : d; } },
            { data: 'timeout', title: 'Timeout', render: function(d, type){ if(type === 'display'){ if(!d){ return ''; } var now = new Date(); var t = new Date(d.replace(' ', 'T')); return now < t ? d : ''; } return d; } },
            { data: 'timeout', title: 'In timeout', className: 'rp-icon-col', render: function(d, type){ if(!d){ return type === 'display' ? '' : 0; } var now = new Date(); var t = new Date(d.replace(' ', 'T')); var active = now < t; if(type === 'display'){ return active ? '<span class="dashicons dashicons-clock rp-icon-clock"></span>' : ''; } return active ? 1 : 0; } },
            { data: null, title: 'Azioni', className: 'rp-action-group-col', orderable: false, render: function(d){ return actionButtons('users', d); } }
        ],
        events: [
            { data: null, title: '', orderable: false, render: renderCheckbox },
            { data: 'name', title: 'Nome', render: function(d, type, row){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-event-detail&id=' + row.id + '">' + d + '</a>'; } },
            { data: 'id', title: 'ID', render: function(d){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-event-detail&id=' + d + '">' + d + '</a>'; } },
            { data: 'group_id', title: 'Gruppo', render: function(d, type, row){
                if(!d || !row.group_name){ return ''; }
                if(type === 'display'){
                    return '<a href="' + rp_admin.admin_url + '?page=res-pong-event-detail&id=' + d + '">' + row.group_name + ' (' + d + ')</a>';
                }
                return d;
            } },
            { data: 'start_datetime', title: 'Inizio' },
            { data: 'end_datetime', title: 'Fine' },
            { data: 'category', title: 'Categoria' },
            { data: 'enabled', title: 'Abilitato', className: 'rp-icon-col', render: function(d, type, row){ return type === 'display' ? renderBool(d, row.id) : d; } },
            { data: null, title: 'Stato', render: function(d){ var now = new Date(); var start = new Date(d.start_datetime.replace(' ', 'T')); return now > start ? 'chiuso' : 'aperto'; } },
            { data: 'players_count', title: 'Giocatori' },
            { data: 'max_players', title: 'Giocatori max' },
            { data: null, title: 'Azioni', className: 'rp-action-group-col', orderable: false, render: function(d){ return actionButtons('events', d); } }
        ],
        reservations: [
            { data: 'id', title: 'ID', render: function(d){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-reservation-detail&id=' + d + '">' + d + '</a>'; } },
            { data: 'name', title: 'Utente', render: function(d, type, row){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-user-detail&id=' + row.user_id + '">' + d + '</a>'; } },
            { data: 'presence_confirmed', title: 'Presenza', className: 'rp-icon-col', render: function(d, type, row){ return type === 'display' ? renderBool(d, row.id) : d; } },
            { data: 'event_name', title: 'Evento', render: function(d, type, row){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-event-detail&id=' + row.event_id + '">' + d + ' (' + row.event_id + ')</a>'; } },
            { data: 'group_name', title: 'Gruppo Evento', render: function(d, type, row){ if(!row.group_id || !d){ return ''; } return '<a href="' + rp_admin.admin_url + '?page=res-pong-event-detail&id=' + row.group_id + '">' + d + '</a>'; } },
            { data: 'event_start_datetime', title: 'Data evento' },
            { data: 'created_at', title: 'Prenotato il' },
            { data: null, title: 'Azioni', className: 'rp-action-group-col', orderable: false, render: function(d){ return actionButtons('reservations', d); } }
        ],
        user_reservations: [
            { data: 'event_name', title: 'Evento', render: function(d, type, row){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-event-detail&id=' + row.event_id + '">' + d + ' (' + row.event_id + ')</a>'; } },
            { data: 'event_start_datetime', title: 'Data evento' },
            { data: 'group_name', title: 'Gruppo Evento', render: function(d, type, row){ if(!row.group_id || !d){ return ''; } return '<a href="' + rp_admin.admin_url + '?page=res-pong-event-detail&id=' + row.group_id + '">' + d + '</a>'; } },
            { data: 'id', title: 'ID', render: function(d){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-reservation-detail&id=' + d + '">' + d + '</a>'; } },
            { data: 'created_at', title: 'Prenotato il' },
            { data: 'presence_confirmed', title: 'Presenza', className: 'rp-icon-col', render: function(d, type, row){ return type === 'display' ? renderBool(d, row.id) : d; } },
            { data: null, title: 'Azioni', className: 'rp-action-group-col', orderable: false, render: function(d){ return actionButtons('user_reservations', d); } }
        ],
        event_reservations: [
            { data: 'name', title: 'Utente', render: function(d, type, row){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-user-detail&id=' + row.user_id + '">' + d + '</a>'; } },
            { data: 'presence_confirmed', title: 'Presenza', className: 'rp-icon-col', render: function(d, type, row){ return type === 'display' ? renderBool(d, row.id) : d; } },
            { data: 'id', title: 'ID', render: function(d){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-reservation-detail&id=' + d + '">' + d + '</a>'; } },
            { data: 'created_at', title: 'Prenotato il' },
            { data: null, title: 'Azioni', className: 'rp-action-group-col', orderable: false, render: function(d){ return actionButtons('event_reservations', d); } }
        ],
        event_notifications: [
            { data: 'user_id', title: 'ID', render: function(d){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-user-detail&id=' + d + '">' + d + '</a>'; } },
            { data: 'name', title: 'Nome', render: function(d, type, row){ return '<a href="' + rp_admin.admin_url + '?page=res-pong-user-detail&id=' + row.user_id + '">' + d + '</a>'; } },
            { data: null, title: 'Azioni', className: 'rp-action-group-col', orderable: false, render: function(d){ return '<div class="rp-action-group"><button class="button rp-delete rp-button-danger rp-action-btn" data-id="' + d.user_id + '" title="Elimina"><span class="dashicons dashicons-trash"></span></button></div>'; } }
        ]
    };
    function handleActions(table, entity){
        table.on('click', '.rp-edit', function(){
            var id = $(this).data('id');
            window.location = rp_admin.admin_url + '?page=res-pong-' + entity.slice(0,-1) + '-detail&id=' + id;
        });
        table.on('click', '.rp-delete', function(){
            var id = $(this).data('id');
            var row = table.DataTable().row($(this).closest('tr')).data();
            var path = entity + '/' + id;
            var params = '';
            var proceed = function(){
                if(!confirm('Eliminare l\'elemento?')){ return; }
                clearNotice();
                showOverlay(true);
                $.ajax({
                    url: restUrl(path, params),
                    method: 'DELETE',
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    complete: function(){ hideOverlay(); },
                    success: function(){ table.DataTable().ajax.reload(); },
                    error: function(xhr){
                        var msg = 'Errore durante l\'eliminazione';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        showNotice('error', msg);
                    }
                });
            };
            if(entity === 'events' && row.group_id !== null){
                rpConfirm('Applicare la modifica a tutta la serie di eventi?').then(function(apply){
                    if(apply){ params = 'apply_group=1'; }
                    proceed();
                });
            } else {
                proceed();
            }
        });
        table.on('click', '.rp-toggle', function(){
            var id = $(this).data('id');
            var row = table.DataTable().row($(this).closest('tr')).data();
            var data = {};
            if(entity === 'reservations'){
                data.presence_confirmed = row.presence_confirmed == 1 ? 0 : 1;
            }else{
                data.enabled = row.enabled == 1 ? 0 : 1;
            }
            var path = entity + '/' + id;
            var params = '';
            var send = function(){
                clearNotice();
                showOverlay(true);
                $.ajax({
                    url: restUrl(path, params),
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    complete: function(){ hideOverlay(); },
                    success: function(){ table.DataTable().ajax.reload(); },
                    error: function(xhr){
                        var msg = 'Errore durante l\'aggiornamento';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        showNotice('error', msg);
                    }
                });
            };
            if(entity === 'events' && row.group_id !== null){
                rpConfirm('Applicare la modifica a tutta la serie di eventi?').then(function(apply){
                    if(apply){ params = 'apply_group=1'; }
                    send();
                });
            } else {
                send();
            }
        });
        if(entity === 'users'){
            table.on('click', '.rp-invite', function(){
                var id = $(this).data('id');
                clearNotice();
                showOverlay(true);
                $.ajax({
                    url: restUrl( 'users/' + id + '/invite'),
                    method: 'POST',
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    complete: function(){ hideOverlay(); },
                    success: function(){ showNotice('success', 'Invito inviato'); },
                    error: function(xhr){
                        var msg = 'Invito fallito';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        showNotice('error', msg);
                    }
                });
            });
            table.on('click', '.rp-impersonate', function(){
                var id = $(this).data('id');
                clearNotice();
                showOverlay(true);
                $.ajax({
                    url: restUrl('users/' + id + '/impersonate'),
                    method: 'POST',
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    complete: function(){ hideOverlay(); },
                    success: function(resp){ if(resp && resp.url){
                        localStorage.setItem('res_pong_user', JSON.stringify(resp.user));
                        window.open(resp.url, '_blank'); } },
                    error: function(xhr){
                        var msg = 'Impersonificazione fallita';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        showNotice('error', msg);
                    }
                });
            });
        }else if(entity === 'events'){
            table.on('click', '.rp-contact', function(){
                var id = $(this).data('id');
                window.location = rp_admin.admin_url + '?page=res-pong-email&event_id=' + id;
            });
        }
    }
    function initTable(table, entity, urlFunc, opts){
        opts = opts || {};
        var order = opts.order || [];
        if(!order.length){
            if(entity === 'users'){ order = [[1, 'asc']]; }
            else if(entity === 'events'){ order = [[2, 'desc']]; }
            else if(entity === 'reservations'){ order = [[4, 'desc']]; }
        }
        var columnsDef = opts.columns || columns[entity];
        var selectable = opts.selectable !== undefined ? opts.selectable : true;
        var showAll = false;
        var dt = table.DataTable({
            ajax: {
                url: urlFunc(showAll),
                dataSrc: '',
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); }
            },
            columns: columnsDef,
            order: order,
            pageLength: 50
        });
        dt.on('preXhr.dt', function(){ showOverlay(true); });
        dt.on('xhr.dt error.dt', function(){ hideOverlay(); });

        if(selectable){
            $(dt.column(0).header()).html('<input type="checkbox" id="rp-select-all">');
            table.on('change', '#rp-select-all', function(){
                var checked = $(this).is(':checked');
                table.find('.rp-select').prop('checked', checked);
            });
            table.on('change', '.rp-select', function(){
                if(!this.checked){ $('#rp-select-all').prop('checked', false); }
            });
        }

        handleActions(table, entity);

        var wrapper = $(dt.table().container());
        var toolbar = $('<div class="rp-toolbar"></div>');
        var length = wrapper.find('div.dataTables_length');
        var filter = wrapper.find('div.dataTables_filter');
        toolbar.append(length);
        if(selectable){
            var bulk = $('<div class="rp-bulk"><select id="rp-bulk-action"><option value="">Bulk Actions</option></select> <button class="button" id="rp-apply-bulk">Applica</button></div>');
            var opt = '';
            if(entity === 'users'){
                opt = '<option value="delete">Elimina</option><option value="enable">Abilita</option><option value="disable">Disabilita</option><option value="timeout">Timeout</option>';
            }else if(entity === 'events'){
                opt = '<option value="delete">Elimina</option><option value="enable">Abilita</option><option value="disable">Disabilita</option>';
            }else if(entity === 'reservations'){
                opt = '<option value="delete">Elimina</option><option value="enable">Presente</option><option value="disable">Assente</option>';
            }
            bulk.find('select').append(opt);
            toolbar.append($('<span>•</span>'), bulk);
        }
        var addBtn = $('<button class="button rp-button-add" id="res-pong-add"><span class="dashicons dashicons-plus"></span><span>Aggiungi</span></button>');
        toolbar.append($('<span>•</span>'), addBtn);
        var importBtn, exportBtn;
        if(!opts.noCsv){
            importBtn = $('<button class="button" id="res-pong-import">Importa CSV</button>');
            exportBtn = $('<button class="button" id="res-pong-export">Esporta CSV</button>');
            toolbar.append($('<span>•</span>'), importBtn, exportBtn);
        }
        var addFilter = typeof opts.filterFuture === 'boolean' ? opts.filterFuture : (entity === 'events' || entity === 'reservations');
        if(addFilter){
            var futureFilter = $('<label>Filtra <select class="rp-future-filter"><option value="0">Solo Futuro</option><option value="1">Mostra tutto</option></select></label>');
            toolbar.append($('<span>•</span>'), futureFilter);
        }
        toolbar.append(filter);
        wrapper.prepend(toolbar);

        addBtn.on('click', function(e){
            e.preventDefault();
            var url = rp_admin.admin_url + '?page=res-pong-' + entity.slice(0,-1) + '-detail';
            if(opts.addParams){
                url += '&' + opts.addParams;
            }
            window.location = url;
        });
        if(!opts.noCsv){
            exportBtn.on('click', function(e){
                e.preventDefault();
                window.location = restUrl(entity + '/export', '_wpnonce=' + rp_admin.nonce);
            });
            importBtn.on('click', function(e){
                e.preventDefault();
                var input = $('<input type="file" accept=".csv" style="display:none">');
                $('body').append(input);
                input.on('change', function(){
                    var file = this.files[0];
                    if(!file){ input.remove(); return; }
                    clearNotice();
                    showOverlay(true);
                    var reader = new FileReader();
                    reader.onload = function(ev){
                        var lines = ev.target.result.split(/\r?\n/).filter(function(l){ return l.trim() !== ''; });
                        var header = lines.shift();
                        var index = 0;
                        function sendChunk(){
                            if(index >= lines.length){
                                hideOverlay();
                                input.remove();
                                dt.ajax.reload();
                                return;
                            }
                            var chunkLines = lines.slice(index, index + 10);
                            index += 10;
                            var csv = [header].concat(chunkLines).join('\n');
                            $.ajax({
                                url: restUrl(entity + '/import'),
                                method: 'POST',
                                contentType: 'application/json',
                                data: JSON.stringify({csv: csv}),
                                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                                success: function(){ sendChunk(); },
                                error: function(xhr){ var msg = 'Errore durante l\'import'; if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; } showNotice('error', msg); hideOverlay(); input.remove(); dt.ajax.reload(); }
                            });
                        }
                        sendChunk();
                    };
                    reader.readAsText(file);
                }).trigger('click');
            });
        }
        if(selectable){
            toolbar.find('#rp-apply-bulk').on('click', function(){
                var action = $('#rp-bulk-action').val();
                var ids = table.find('.rp-select:checked').map(function(){ return this.value; }).get();
                if(!action || ids.length === 0){ return; }
                if(action === 'delete' && !confirm('Elimina elementi selezionati?')){ return; }
                var timeoutDate = null;
                if(action === 'timeout'){
                    var def = new Date();
                    def.setHours(0,0,0,0);
                    def.setDate(def.getDate() + 7);
                    var defStr = def.getFullYear() + '-' + ('0' + (def.getMonth()+1)).slice(-2) + '-' + ('0' + def.getDate()).slice(-2) + ' 00:00:00';
                    timeoutDate = prompt('Timeout date (YYYY-MM-DD HH:MM:SS)', defStr);
                    if(!timeoutDate){ return; }
                }
                clearNotice();
                var overlay = showOverlay(false);
                var bar = overlay.bar;
                var text = overlay.text;
                var i = 0;
                function next(){
                    if(i >= ids.length){ hideOverlay(); dt.ajax.reload(); return; }
                    var id = ids[i];
                    var url = restUrl(entity + '/' + id);
                    var method = action === 'delete' ? 'DELETE' : 'PUT';
                    var data = null;
                    if(action === 'enable'){ data = entity === 'reservations' ? { presence_confirmed:1 } : { enabled:1 }; }
                    if(action === 'disable'){ data = entity === 'reservations' ? { presence_confirmed:0 } : { enabled:0 }; }
                    if(action === 'timeout'){ data = { timeout: timeoutDate }; }
                    $.ajax({
                        url: url,
                        method: method,
                        contentType: 'application/json',
                        data: data ? JSON.stringify(data) : null,
                        beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                        complete: function(){
                            i++;
                            var perc = Math.round(i / ids.length * 100);
                            bar.val(perc); text.text(perc + '%');
                            next();
                        }
                    });
                }
                next();
            });
        }
        if(addFilter){
            toolbar.find('.rp-future-filter').on('change', function(){
                showAll = $(this).val() === '1';
                dt.ajax.url(urlFunc(showAll)).load();
            });
        }
        return dt;
    }
    function populateForm(entity, id, form){
        $.ajax({
            url: restUrl(entity + '/' + id),
            method: 'GET',
            beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
            success: function(data){
                for(var key in data){
                    if(!Object.prototype.hasOwnProperty.call(data, key)){ continue; }
                    var field = form.find('[name='+key+']');
                    if(!field.length){ continue; }
                    var value = data[key];
                    if(value === null || typeof value === 'undefined'){
                        value = '';
                    }
                    if(field.attr('type') === 'checkbox'){
                        field.prop('checked', parseInt(data[key]) === 1);
                    } else if(field.attr('type') === 'datetime-local'){
                        if(typeof data[key] === 'string'){
                            field.val(data[key].replace(' ', 'T'));
                        } else {
                            field.val('');
                        }
                    } else if(field.hasClass('wp-editor-area')){
                        field.val(value);
                        if(typeof tinymce !== 'undefined'){
                            var editor = tinymce.get(field.attr('id'));
                            if(editor){
                                editor.setContent(value);
                            }
                        }
                    } else {
                        field.val(value);
                    }
                }
                if(entity === 'events'){
                    var gSel = form.find('[name=group_id]');
                    if(parseInt(data.group_id) === 0){
                        gSel.val('');
                        gSel.find('option[value="' + id + '"]').prop('disabled', true);
                    }else if(data.group_id){
                        if(!gSel.find('option[value="' + data.group_id + '"]').length){
                            gSel.val('');
                        }
                    }
                    form.data('has_group', data.group_id !== null);
                }
                if(typeof data.password !== 'undefined'){
                    var hasPassword = !!data.password;
                    $('#rp-invite-wrapper').toggle(!hasPassword);
                    $('#rp-reset-wrapper').toggle(hasPassword);
                }
            }
        });
    }
    function initDetail(){
        var form = $('#res-pong-detail-form');
        if(!form.length){ return; }
        var entity = form.data('entity');
        var id = form.data('id');
        var params = new URLSearchParams(window.location.search);
        var preUser = params.get('user_id');
        var preEvent = params.get('event_id');
        function loadReservationOptions(callback){
            var uReq = $.ajax({
                url: restUrl('users'),
                method: 'GET',
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); }
            });
            var eReq = $.ajax({
                url: restUrl('events', 'open_only=0'),
                method: 'GET',
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); }
            });
            $.when(uReq, eReq).done(function(uRes, eRes){
                var users = uRes[0];
                var events = eRes[0];
                var uSel = $('#user_id');
                users.sort(function(a, b){
                    var nameA = (a.last_name + ' ' + a.first_name).toUpperCase();
                    var nameB = (b.last_name + ' ' + b.first_name).toUpperCase();
                    if(nameA < nameB){ return -1; }
                    if(nameA > nameB){ return 1; }
                    return 0;
                });
                $.each(users, function(_, u){
                    uSel.append('<option value="' + u.id + '">' + u.last_name + ' ' + u.first_name + ' (' + u.id + ')</option>');
                });
                var eSel = $('#event_id');
                $.each(events, function(_, e){
                    var dt = e.start_datetime.substring(0,16);
                    eSel.append('<option value="' + e.id + '">' + e.name + ' - ' + dt + ' (' + e.id + ')</option>');
                });
                if(!id){
                    if(preUser){ uSel.val(preUser); }
                    if(preEvent){ eSel.val(preEvent); }
                }
                if(callback){ callback(); }
            });
        }
        function loadEventGroupOptions(callback){
            var sel = $('#group_id');
            sel.html('<option value="">Caricamento...</option>');
            $.ajax({
                url: restUrl('events', 'open_only=0'),
                method: 'GET',
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                success: function(events){
                    sel.empty();
                    sel.append('<option value="">Nessuno</option>');
                    $.each(events, function(_, e){
                        if(e.group_id === null || parseInt(e.group_id) === 0){
                            var g = e.group_id === null ? '' : e.group_id;
                            sel.append('<option value="' + e.id + '" data-group="' + g + '">' + e.name + ' (' + e.id + ')</option>');
                        }
                    });
                    if(callback){ callback(); }
                }
            });
        }
        function setupRecurrence(){
            function toggle(){
                if($('#group_id').val()){
                    $('#recurrence_row, #recurrence_end_row').hide();
                }else{
                    $('#recurrence_row, #recurrence_end_row').show();
                    $('#recurrence_end').prop('disabled', $('#recurrence').val() === 'none');
                }
            }
            $('#group_id').on('change', toggle);
            $('#recurrence').on('change', function(){
                $('#recurrence_end').prop('disabled', $('#recurrence').val() === 'none');
            });
            if(id){
                $('#recurrence_row, #recurrence_end_row').hide();
            }else{
                toggle();
            }
        }
        function initForm(){ if(id){ populateForm(entity, id, form); } }
        if(entity === 'reservations'){
            loadReservationOptions(initForm);
        }else if(entity === 'events'){
            loadEventGroupOptions(function(){ initForm(); setupRecurrence(); });
        }else{
            initForm();
        }
        form.on('submit', function(e){
            e.preventDefault();
            if(typeof tinymce !== 'undefined' && typeof tinymce.triggerSave === 'function'){
                tinymce.triggerSave();
            }
            var data = {};
            form.serializeArray().forEach(function(item){ data[item.name] = item.value; });
            form.find('input[type=checkbox]').each(function(){ data[this.name] = $(this).is(':checked') ? 1 : 0; });
            form.find('input[type=datetime-local]').each(function(){
                var val = this.value;
                if(val && val.length === 16){ val += ':00'; }
                data[this.name] = val.replace('T', ' ');
            });
            var method = id ? 'PUT' : 'POST';
            var path = id ? (entity + '/' + id) : entity;
            var params = '';
            var send = function(){
                $.ajax({
                    url: restUrl(path, params),
                    method: method,
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    complete: function(){ hideOverlay(); },
                    success: function(resp){
                        if(entity === 'reservations' && !id){
                            showNotice('success', 'Prenotazione salvata');
                        }else{
                            showButtonMessage(form.find('button[type=submit]'), 'success', 'Salvato');
                        }
                        if(!id && resp && resp.id){
                            if(entity === 'users' || entity === 'events'){
                                setTimeout(function(){
                                    window.location = rp_admin.admin_url + '?page=res-pong-' + entity.slice(0,-1) + '-detail&id=' + resp.id;
                                }, 2000);
                            }else if(entity === 'reservations'){
                                setTimeout(function(){
                                    window.location = rp_admin.admin_url + '?page=res-pong-reservation-detail&id=' + resp.id;
                                }, 1000);
                            }else{
                                id = resp.id;
                                form.attr('data-id', id);
                                history.replaceState(null, '', rp_admin.admin_url + '?page=res-pong-' + entity.slice(0,-1) + '-detail&id=' + id);
                            }
                        }
                    },
                    error: function(xhr){
                        var msg = 'Errore durante il salvataggio';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        var type = xhr.status === 409 ? 'warning' : 'error';
                        showButtonMessage(form.find('button[type=submit]'), type, msg);
                    }
                });
            };
            var ensureMaster = function(cb){
                if(entity === 'events' && data.group_id){
                    var opt = $('#group_id option:selected');
                    var gid = opt.data('group');
                    if(gid === undefined || gid === null || gid === ''){
                        $.ajax({
                            url: restUrl('events/' + data.group_id),
                            method: 'PUT',
                            contentType: 'application/json',
                            data: JSON.stringify({ group_id: 0 }),
                            beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                            success: cb,
                            error: cb
                        });
                        return;
                    }
                }
                cb();
            };
            var submit = function(){
                clearNotice();
                showOverlay(true);
                ensureMaster(send);
            };
            if(entity === 'events' && id && form.data('has_group')){
                rpConfirm('Applicare la modifica a tutta la serie di eventi?').then(function(apply){
                    if(apply){ params = 'apply_group=1'; }
                    submit();
                });
            } else {
                submit();
            }
        });
        $('#res-pong-delete').on('click', function(e){
            e.preventDefault();
            if(!id){ return; }
            var path = entity + '/' + id;
            var params = '';
            var executeDelete = function(){
                if(!confirm('Eliminare l\'elemento?')){ return; }
                clearNotice();
                showOverlay(true);
                $.ajax({
                    url: restUrl(path, params),
                    method: 'DELETE',
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    complete: function(){ hideOverlay(); },
                    success: function(){
                        window.location = rp_admin.admin_url + '?page=res-pong-' + entity;
                    },
                    error: function(xhr){
                        var msg = 'Errore durante l\'eliminazione';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        showButtonMessage($('#res-pong-delete'), 'error', msg);
                    }
                });
            };
            if(entity === 'events' && form.data('has_group')){
                rpConfirm('Applicare la modifica a tutta la serie di eventi?').then(function(apply){
                    if(apply){ params = 'apply_group=1'; }
                    executeDelete();
                });
            } else {
                executeDelete();
            }
        });
        $('#res-pong-impersonate').on('click', function(){
            if(!id){ return; }
            clearNotice();
            showOverlay(true);
            $.ajax({
                url: restUrl('users/' + id + '/impersonate'),
                method: 'POST',
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                complete: function(){ hideOverlay(); },
                success: function(resp){ if(resp && resp.url){
                    localStorage.setItem('res_pong_user', JSON.stringify(resp.user));
                    window.open(resp.url, '_blank'); } },
                error: function(xhr){
                    var msg = 'Impersonificazione fallita';
                    if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                    showNotice('error', msg);
                }
            });
        });
        var pwdForm = $('#res-pong-password-form');
        if(pwdForm.length){
            pwdForm.on('submit', function(e){
                e.preventDefault();
                var pass = $('#new_password').val();
                var confirm = $('#confirm_password').val();
            if(pass.length < 6 || pass !== confirm){
                showButtonMessage(pwdForm.find('button[type=submit]'), 'error', 'Le password devono coincidere ed essere lunghe almeno 6 caratteri.');
                return;
            }
            clearNotice();
            showOverlay(true);
            $.ajax({
                url: restUrl('users/' + id + '/reset-password'),
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ password: pass }),
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                complete: function(){ hideOverlay(); },
                success: function(){ showButtonMessage(pwdForm.find('button[type=submit]'), 'success', 'Password salvata'); },
                error: function(xhr){
                    var msg = 'Errore durante il salvataggio della password';
                    if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                    showButtonMessage(pwdForm.find('button[type=submit]'), 'error', msg);
                }
            });
        });
        $('#rp-send-invite').on('click', function(){
            var text = $('#rp-invite-text').val();
            clearNotice();
            showOverlay(true);
            $.ajax({
                url: restUrl('users/' + id + '/invite'),
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ text: text }),
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                complete: function(){ hideOverlay(); },
                success: function(){ showButtonMessage($('#rp-send-invite'), 'success', 'Invito inviato'); },
                error: function(xhr){
                    var msg = 'Invito fallito';
                    if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                    showButtonMessage($('#rp-send-invite'), 'error', msg);
                }
            });
        });
        $('#rp-send-reset').on('click', function(){
            var text = $('#rp-reset-text').val();
            clearNotice();
            showOverlay(true);
            $.ajax({
                url: restUrl('users/' + id + '/reset-password'),
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ text: text }),
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                complete: function(){ hideOverlay(); },
                success: function(){ showButtonMessage($('#rp-send-reset'), 'success', 'Reset inviato'); },
                error: function(xhr){
                    var msg = 'Errore durante il reset';
                    if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                    showButtonMessage($('#rp-send-reset'), 'error', msg);
                }
            });
        });
        }
        var timeoutForm = $('#res-pong-timeout-form');
        if(timeoutForm.length){
            if(id){ populateForm('users', id, timeoutForm); }
            timeoutForm.on('submit', function(e){
                e.preventDefault();
                var val = timeoutForm.find('[name=timeout]').val();
                if(!val){ return; }
                clearNotice();
                showOverlay(true);
                $.ajax({
                    url: restUrl('users/' + id),
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({ timeout: val.replace('T', ' ') }),
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    complete: function(){ hideOverlay(); },
                    success: function(){ showButtonMessage(timeoutForm.find('button[type=submit]'), 'success', 'Timeout salvato'); },
                    error: function(xhr){
                        var msg = 'Errore durante il salvataggio del timeout';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        showButtonMessage(timeoutForm.find('button[type=submit]'), 'error', msg);
                    }
                });
            });
            $('#rp-remove-timeout').on('click', function(){
                clearNotice();
                showOverlay(true);
                $.ajax({
                    url: restUrl('users/' + id),
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({ timeout: null }),
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    complete: function(){ hideOverlay(); },
                    success: function(){
                        timeoutForm.find('[name=timeout]').val('');
                        showButtonMessage($('#rp-remove-timeout'), 'success', 'Timeout rimosso');
                    },
                    error: function(xhr){
                        var msg = 'Errore durante la rimozione del timeout';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        showButtonMessage($('#rp-remove-timeout'), 'error', msg);
                    }
                });
            });
        }
    }

    function initConfigPage(){
        var form = $('#rp-config-form');
        if(!form.length){ return; }
        var importBtn = $('#rp-config-import');
        var exportBtn = $('#rp-config-export');
        exportBtn.on('click', function(e){
            e.preventDefault();
            window.location = restUrl('configurations/export', '_wpnonce=' + rp_admin.nonce);
        });
        importBtn.on('click', function(e){
            e.preventDefault();
            var input = $('<input type="file" accept="application/json" style="display:none">');
            $('body').append(input);
            input.on('change', function(){
                var file = this.files[0];
                if(!file){ input.remove(); return; }
                clearNotice();
                showOverlay(true);
                var reader = new FileReader();
                reader.onload = function(ev){
                    var conf;
                    try{ conf = JSON.parse(ev.target.result); }catch(err){ showNotice('error', 'File JSON non valido'); hideOverlay(); input.remove(); return; }
                    $.ajax({
                        url: restUrl('configurations/import'),
                        method: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify({config: conf}),
                        beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                        complete: function(){ hideOverlay(); input.remove(); },
                        success: function(){ showNotice('success', 'Configurazioni importate'); location.reload(); },
                        error: function(xhr){ var msg = 'Errore durante l\'import'; if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; } showNotice('error', msg); }
                    });
                };
                reader.readAsText(file);
            }).trigger('click');
        });
    }

    function initEmailPage(){
        var form = $('#rp-messenger-form');
        if(!form.length){ return; }
        var toInput = $('#rp-messenger-to');
        var btn = form.find('button[type=submit]');
        $.ajax({
            url: restUrl('users'),
            method: 'GET',
            beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
            success: function(users){
                var items = users.map(function(u){
                    var label = u.email + ' (' + u.last_name + ' ' + u.first_name + ')';
                    var search = (u.email + ' ' + u.last_name + ' ' + u.first_name).toLowerCase();
                    return { label: label, value: u.email, search: search };
                });
                toInput.autocomplete({
                    source: function(request, response){
                        var term = request.term.toLowerCase().split(/,\s*/).pop();
                        response(items.filter(function(it){ return it.search.indexOf(term) !== -1; }));
                    },
                    minLength: 0,
                    focus: function(){ return false; },
                    select: function(event, ui){
                        var terms = toInput.val().split(/,\s*/);
                        terms.pop();
                        terms.push(ui.item.value);
                        terms.push('');
                        toInput.val(terms.join(', '));
                        return false;
                    }
                }).on('keydown', function(event){
                    if(event.keyCode === $.ui.keyCode.TAB && $(this).autocomplete('instance').menu.active){
                        event.preventDefault();
                    }
                }).on('focus', function(){ $(this).autocomplete('search', ''); });
            }
        });
        var params = new URLSearchParams(window.location.search);
        var eventId = params.get('event_id');
        if(eventId){
            $.ajax({
                url: restUrl('reservations', 'event_id=' + eventId + '&active_only=1'),
                method: 'GET',
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                success: function(res){
                    var emails = res.map(function(r){ return r.email; });
                    toInput.val(emails.join(', '));
                }
            });
        }
        form.on('submit', function(e){
            e.preventDefault();
            var recipients = toInput.val().split(',').map(function(s){ return s.trim(); }).filter(Boolean);
            var data = {
                subject: $('#rp-messenger-subject').val(),
                text: $('#rp-messenger-text').val(),
                recipients: recipients
            };
            btn.prop('disabled', true);
            showOverlay(true);
            $.ajax({
                url: restUrl('email'),
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(data),
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                complete: function(){ btn.prop('disabled', false); hideOverlay(); },
                success: function(){ showButtonMessage(btn, 'success', 'Email inviata'); },
                error: function(xhr){
                    var msg = 'Errore invio email';
                    if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                    showButtonMessage(btn, 'error', msg);
                }
            });
        });
    }
    function initEventReservationAdder(dt, eid){
        var wrapper = $(dt.table().container());
        var addBtn = wrapper.find('#res-pong-add');
        addBtn.off('click');
        addBtn.prop('disabled', true);
        var select = $('<select id="rp-event-reservation-user"><option value="">Seleziona utente</option></select>');
        var bullet = addBtn.prev('span');
        bullet.after(select);
        var message = $('#res-pong-event-reservations-message');
        $.ajax({
            url: restUrl('users'),
            method: 'GET',
            beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
            success: function(users){
                users.sort(function(a, b){
                    var la = a.last_name.toLowerCase();
                    var lb = b.last_name.toLowerCase();
                    if(la < lb){ return -1; }
                    if(la > lb){ return 1; }
                    var fa = a.first_name.toLowerCase();
                    var fb = b.first_name.toLowerCase();
                    if(fa < fb){ return -1; }
                    if(fa > fb){ return 1; }
                    return a.id - b.id;
                });
                users.forEach(function(u){
                    var label = u.last_name + ' ' + u.first_name + ' (' + u.id + ')';
                    select.append('<option value="' + u.id + '">' + label + '</option>');
                });
                sync();
            }
        });
        function sync(){
            var existing = dt.rows().data().toArray().map(function(r){ return String(r.user_id); });
            select.find('option').each(function(){
                var val = $(this).val();
                if(!val){ return; }
                $(this).prop('disabled', existing.indexOf(val) !== -1);
            });
            check();
        }
        function check(){
            var uid = select.val();
            addBtn.prop('disabled', !uid || select.find('option:selected').is(':disabled'));
        }
        dt.on('draw', sync);
        select.on('change', check);
        addBtn.on('click', function(e){
            e.preventDefault();
            var uid = select.val();
            if(!uid){ return; }
            addBtn.prop('disabled', true);
            $.ajax({
                url: restUrl('reservations'),
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ event_id: eid, user_id: uid }),
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                success: function(){
                    message.html('<div class="notice notice-success is-dismissible"><p>Prenotazione aggiunta</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
                    select.val('');
                    dt.ajax.reload(sync, false);
                    addBtn.prop('disabled', true);
                },
                error: function(xhr){
                    var msg = 'Errore aggiunta prenotazione';
                    if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                    message.html('<div class="notice notice-error is-dismissible"><p>' + msg + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
                    check();
                }
            });
        });
    }
    function initUserReservationAdder(dt, uid){
        var wrapper = $(dt.table().container());
        var addBtn = wrapper.find('#res-pong-add');
        addBtn.off('click');
        addBtn.prop('disabled', true);
        var select = $('<select id="rp-user-reservation-event"><option value="">Seleziona evento</option></select>');
        var bullet = addBtn.prev('span');
        bullet.after(select);
        var message = $('#res-pong-user-reservations-message');
        $.ajax({
            url: restUrl('events', 'open_only=1'),
            method: 'GET',
            beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
            success: function(events){
                events.sort(function(a, b){
                    var da = new Date(a.start_datetime.replace(' ', 'T'));
                    var db = new Date(b.start_datetime.replace(' ', 'T'));
                    return da - db;
                });
                events.forEach(function(ev){
                    var label = ev.name + ' - ' + ev.start_datetime + ' (' + ev.id + ')';
                    select.append('<option value="' + ev.id + '">' + label + '</option>');
                });
                sync();
            }
        });
        function sync(){
            var existing = dt.rows().data().toArray().map(function(r){ return String(r.event_id); });
            select.find('option').each(function(){
                var val = $(this).val();
                if(!val){ return; }
                $(this).prop('disabled', existing.indexOf(val) !== -1);
            });
            check();
        }
        function check(){
            var eid = select.val();
            addBtn.prop('disabled', !eid || select.find('option:selected').is(':disabled'));
        }
        dt.on('draw', sync);
        select.on('change', check);
        addBtn.on('click', function(e){
            e.preventDefault();
            var eid = select.val();
            if(!eid){ return; }
            addBtn.prop('disabled', true);
            $.ajax({
                url: restUrl('reservations'),
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ user_id: uid, event_id: eid }),
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                success: function(){
                    message.html('<div class="notice notice-success is-dismissible"><p>Prenotazione aggiunta</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
                    select.val('');
                    dt.ajax.reload(sync, false);
                    addBtn.prop('disabled', true);
                },
                error: function(xhr){
                    var msg = 'Errore aggiunta prenotazione';
                    if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                    message.html('<div class="notice notice-error is-dismissible"><p>' + msg + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
                    check();
                }
            });
        });
    }
    function initEventNotifications(table, eid){
        var message = $('#res-pong-event-notifications-message');
        var subs = [];
        var users = [];
        $.when(
            $.ajax({
                url: restUrl('events/' + eid),
                method: 'GET',
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); }
            }),
            $.ajax({
                url: restUrl('users'),
                method: 'GET',
                beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); }
            })
        ).done(function(evRes, usersRes){
            var event = evRes[0];
            users = usersRes[0];
            users.sort(function(a, b){
                var la = a.last_name.toLowerCase();
                var lb = b.last_name.toLowerCase();
                if(la < lb){ return -1; }
                if(la > lb){ return 1; }
                var fa = a.first_name.toLowerCase();
                var fb = b.first_name.toLowerCase();
                if(fa < fb){ return -1; }
                if(fa > fb){ return 1; }
                return a.id - b.id;
            });
            subs = event.notification_subscribers ? JSON.parse(event.notification_subscribers) : [];
            var data = subs.map(function(uid){
                var u = users.find(function(us){ return String(us.id) === String(uid); });
                var name = u ? u.last_name + ' ' + u.first_name : uid;
                return { user_id: String(uid), name: name };
            });
            var dt = table.DataTable({
                data: data,
                columns: columns.event_notifications,
                order: [[0, 'asc']],
                pageLength: 50
            });
            var wrapper = $(dt.table().container());
            var addBtn = $('<button class="button rp-button-add" id="res-pong-notification-add"><span class="dashicons dashicons-plus"></span><span>Aggiungi</span></button>');
            var select = $('<select id="rp-event-notification-user"><option value="">Seleziona utente</option></select>');
            users.forEach(function(u){
                var label = u.last_name + ' ' + u.first_name + ' (' + u.id + ')';
                select.append('<option value="' + u.id + '">' + label + '</option>');
            });
            function check(){
                var uid = select.val();
                addBtn.prop('disabled', !uid || select.find('option:selected').is(':disabled'));
            }
            function sync(){
                select.find('option').each(function(){
                    var val = $(this).val();
                    if(!val){ return; }
                    $(this).prop('disabled', subs.indexOf(val) !== -1);
                });
                check();
            }
            var length = wrapper.find('div.dataTables_length');
            var filter = wrapper.find('div.dataTables_filter');
            var toolbar = $('<div class="rp-toolbar"></div>');
            toolbar.append(length).append($('<span>•</span>'), select).append($('<span>•</span>'), addBtn).append(filter);
            wrapper.prepend(toolbar);
            select.on('change', check);
            addBtn.on('click', function(e){
                e.preventDefault();
                var uid = select.val();
                if(!uid){ return; }
                var newSubs = subs.slice();
                newSubs.push(uid);
                $.ajax({
                    url: restUrl('events/' + eid),
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({ notification_subscribers: JSON.stringify(newSubs) }),
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    success: function(){
                        subs = newSubs;
                        var user = users.find(function(u){ return String(u.id) === uid; });
                        dt.row.add({ user_id: uid, name: user.last_name + ' ' + user.first_name }).draw();
                        message.html('<div class="notice notice-success is-dismissible"><p>Utente aggiunto</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
                        select.val('');
                        sync();
                    },
                    error: function(xhr){
                        var msg = 'Errore aggiunta notifica';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        message.html('<div class="notice notice-error is-dismissible"><p>' + msg + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
                        check();
                    }
                });
            });
            table.on('click', '.rp-delete', function(e){
                e.preventDefault();
                var btn = $(this);
                var uid = String(btn.data('id'));
                var idx = subs.indexOf(uid);
                if(idx === -1){ return; }
                var newSubs = subs.slice();
                newSubs.splice(idx, 1);
                $.ajax({
                    url: restUrl('events/' + eid),
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({ notification_subscribers: JSON.stringify(newSubs) }),
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    success: function(){
                        subs = newSubs;
                        dt.row(btn.closest('tr')).remove().draw();
                        message.html('<div class="notice notice-success is-dismissible"><p>Utente rimosso</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
                        sync();
                    },
                    error: function(xhr){
                        var msg = 'Errore rimozione notifica';
                        if(xhr.responseJSON && xhr.responseJSON.message){ msg += ': ' + xhr.responseJSON.message; }
                        message.html('<div class="notice notice-error is-dismissible"><p>' + msg + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignora questa notifica.</span></button></div>');
                    }
                });
            });
            sync();
        });
    }
    $(function(){
        var list = $('#res-pong-list');
        if(list.length){
            var ent = list.data('entity');
            var opts = { filterFuture: ent === 'events' || ent === 'reservations' };
            if(ent === 'reservations'){ opts.selectable = false; }
            initTable(list, ent, function(showAll){
                var params = '';
                if(ent === 'events'){ params = 'open_only=' + (showAll ? '0' : '1'); }
                else if(ent === 'reservations'){ params = 'active_only=' + (showAll ? '0' : '1'); }
                return restUrl(ent, params);
            }, opts);
        }
        var ur = $('#res-pong-user-reservations');
        if(ur.length){
            var uid = ur.data('user');
            var urTable = initTable(ur, 'reservations', function(showAll){ return restUrl('reservations', 'user_id=' + uid + '&active_only=' + (showAll ? '0' : '1')); }, { columns: columns.user_reservations, addParams: 'user_id=' + uid, noCsv: true, filterFuture: true, selectable: false, order: [[1, 'desc']] });
            initUserReservationAdder(urTable, uid);
        }
        var er = $('#res-pong-event-reservations');
        if(er.length){
            var eid = er.data('event');
            var erTable = initTable(er, 'reservations', function(){ return restUrl('reservations', 'event_id=' + eid + '&active_only=0'); }, { columns: columns.event_reservations, addParams: 'event_id=' + eid, noCsv: true, filterFuture: false, selectable: false, order: [[0, 'asc']] });
            initEventReservationAdder(erTable, eid);
            var title = $('#rp-event-reservations-title');
            if(title.length){
                $.ajax({
                    url: restUrl('events/' + eid),
                    method: 'GET',
                    beforeSend: function(xhr){ xhr.setRequestHeader('X-WP-Nonce', rp_admin.nonce); },
                    success: function(ev){
                        var dt = ev.start_datetime ? ev.start_datetime.substring(0, 16) : '';
                        title.text('Prenotazioni ' + ev.name + ' - ' + dt);
                    }
                });
            }
        }
        var en = $('#res-pong-event-notifications');
        if(en.length){
            var eidn = en.data('event');
            initEventNotifications(en, eidn);
        }
        initConfigPage();
        initDetail();
        initEmailPage();
    });
})(jQuery);
